# My First PHP Repo

Hello! This is my very first repository. I'm just learning Git, GitHub, and PHP.

## Description

This repository contains simple PHP exercises that I am working on as I learn programming concepts. Each folder represents a small project or exercise.

## Folder Structure

- `public/` – files that would be served publicly (e.g., `index.html`, `11.php`)  
- `src/` – PHP source files (classes, functions, etc.)  
- `tests/` – unit tests for the PHP code


TEST
