$db_pass = 'secret123';
