<?php
function saveLead() {
	saveUser(); 
	}
	