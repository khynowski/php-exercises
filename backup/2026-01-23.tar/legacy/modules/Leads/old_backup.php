<?php
function saveUser() { 
// old logic 
}