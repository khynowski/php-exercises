<?php
class UserView {
	}